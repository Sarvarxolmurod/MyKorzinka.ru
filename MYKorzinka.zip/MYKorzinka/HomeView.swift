//
//  HomeView.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 18/12/24.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack(spacing: 40){
            Spacer()
            Textview()
            
            VStack{
            HStack {
                Spacer()
                Text("I have already a card")
                    .foregroundColor(.red)
                    .fontWeight(.semibold)
                    .frame(height: 30)
                
                Spacer()
            }
            .padding()
            .background(
                UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
                    .fill(.white)
            )
            .clipShape(
                UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
            )
            HStack {
                Spacer()
                Text("Issue a new card")
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .frame(height: 30)
                
                Spacer()
            }
            .padding()
            .background(
                UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
                    .fill(.reddish)
            )
            .clipShape(
                UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
            )
            HStack {
                Spacer()
                Text("Add a Bank Card")
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .frame(height: 30)
                Spacer()
                
            }
            
            
        }
            
            
            
        }
        .padding(.vertical, 20)
    }
}

#Preview {
    HomeView()
}
