//
//  Tabview.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 08/01/25.
//

import SwiftUI

struct Tabview: View {
    @State private var index = 0
    @State private var showview: Bool = false
    var body: some View {
        // TabViewp
        ZStack {
         
            TabView(selection: $index) {
                // Home Tab
                HomePage()
                    .tabItem {
                        Image(systemName: "house")
                            .font(.system(size: 24))
                            .fontDesign(.rounded)
                        Text("Home")
                    }
                    .tag(0)
                
                // Discounts Tab
                Text("Discounts")
                    .tabItem {
                        Image(systemName: "percent")
                            .font(.system(size: 24))
                            .fontDesign(.rounded)
                        Text("Discounts")
                    }
                    .tag(1)
                
                // QR Code Tab
                Text("QR Code")
                    .tabItem {
                        Image(systemName: "qrcode.viewfinder")
                            .font(.system(size: 50))
                                             
                                              .fontDesign(.rounded)
                          
                          
                                              .background(
                                                  Ellipse() // Circle shape as the background
                                                      .fill(Color.pink.opacity(0.09)) // Fill the circle with a color (e.g., white)
                                                      .frame(width: 90, height: 70) // Define the circle's size
                          
                                                      .foregroundColor(Color.red)
                                                      .rotationEffect(.degrees(-80))
                                              )
                    }
                    .tag(2)
                
                // Stores Tab
                Text("Stores")
                    .tabItem {
                        Image(systemName: "mappin.and.ellipse")
                            .font(.system(size: 24))
                            .fontDesign(.rounded)
                        Text("Stores")
                    }
                    .tag(3)
                
                // More Tab
                Button(action: {
                    withAnimation {
                        showview.toggle()
                    }
                }) {
                    Text("More Options")
                }
                .tabItem {
                    Image(systemName: "ellipsis.circle")
                        .font(.system(size: 24))
                        .fontDesign(.rounded)
                        .rotationEffect(.degrees(-90))
                    Text("More")
                }
                .tag(4)
            }
          
        }.ignoresSafeArea(edges: .bottom)
            .navigationBarBackButtonHidden()
    }
}

#Preview {
    Tabview()
}
