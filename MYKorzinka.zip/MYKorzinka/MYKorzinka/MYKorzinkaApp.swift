//
//  MYKorzinkaApp.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 06/12/24.
//

import SwiftUI

@main
struct MYKorzinkaApp: App {
    var body: some Scene {
        WindowGroup {
            RegistrationPage()
        }
    }
}
