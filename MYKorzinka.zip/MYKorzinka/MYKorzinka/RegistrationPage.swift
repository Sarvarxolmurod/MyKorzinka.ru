//
//  RegistrationPage.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 06/12/24.
//

import SwiftUI

struct RegistrationPage: View {
    @State private var bgcolor : Color = Color(.systemGray6)
    @State private var fgcolor : Color = Color.gray
    @State var showdetails  = false
    @State private  var phonenumber : String = "+998"
    @State private  var plusloyality : String = "Korzinka Plus Loyalty Programme"
    @State private var navigatetohomepage = false
    private var phoneNumberBinding: Binding<String> {
        Binding(
            get: { self.phonenumber },
            set: {
                if $0.count <= 13 {
                    self.phonenumber = $0
                } else {
                    self.phonenumber = String($0.prefix(13))
                }
                updateColors(for: self.phonenumber)
            }
        )
    }
    private func updateColors(for number: String) {
          if number.count == 13 {
              bgcolor = .red
              fgcolor = .white
          } else {
              bgcolor = Color(.systemGray6)
              fgcolor = .gray
          }
      }
   
    var body: some View {
        
        NavigationView {
            ZStack(alignment: .leading){
                VStack(alignment: .leading, spacing: 20) {
                    
                    HStack() {
                        Text("___Your mobile number___")
                            
                            .font(.system(size: 50, weight: .bold))
                            
                        Spacer()
                    }
                    Text("We will only use your number to register your accaunt. You will not recieve spam")
                        .foregroundStyle(.gray)
                        .fontDesign(.rounded)
                    
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            Text("Phone number")
                                .font(.caption)
                                .foregroundColor(.gray.opacity(0.5))
                            Spacer()
                        }
                        
                        TextField("", text: phoneNumberBinding)
                            .keyboardType(.phonePad)
                        
                        
                    }
                    
                    .padding()
                    .background(
                        UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
                            .fill(Color(UIColor.systemGray6))
                    )
                    .clipShape(
                        UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
                    )
                    .cornerRadius(20)
                    
                    
                    VStack(alignment: .leading, spacing: 0) {
                        
        Text("By clicking \"Continue\" you agree to the terms and ")
                            .foregroundStyle(.gray)
                            .font(.system(size: 14))
                            .fontDesign(.rounded)
                        HStack(spacing: 5){
                            Text("conditions of the")
                                .foregroundStyle(.gray)
                                .font(.system(size: 14))
                                .fontDesign(.rounded)
                            
                            HStack(spacing: 0){
                                Text("Korzinka Plus Loyalty Program")
                                    .foregroundStyle(.gray)
                                    .font(.system(size: 14))
                                    .onTapGesture {
                                        showdetails.toggle()
                                    }
                                    .sheet(isPresented: $showdetails) {
                                        LoyaltyPage()
                                            
                                    }
                                Text("me and")
                                    .foregroundStyle(.gray)
                                    .font(.system(size: 14))
                                    .fontDesign(.rounded)
                            }
                        }
                        
       Text("the processing of your personal data.")
                            .foregroundStyle(.gray)
                            .font(.system(size: 14))
                            .fontDesign(.rounded)

                    }
                   
                    NavigationLink(destination:  TabBarApp()){
                        Spacer()
                        Text("Continue")
                            .foregroundColor(fgcolor)
                            .frame(height: 30)
                        Spacer()
                    }
                    .disabled(phonenumber.count != 13)
                    .padding()
                    .background(
                        UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
                            .fill(bgcolor)
                    )
                    .clipShape(
                        UnevenRoundedRectangle(cornerRadii: (50, 20, 50, 20))
                    )
                    
                    Spacer()
                }.padding()
                
                
            }
        }.navigationBarBackButtonHidden()
        
        
            
        }
 

            
    }


#Preview {
    RegistrationPage()
}
