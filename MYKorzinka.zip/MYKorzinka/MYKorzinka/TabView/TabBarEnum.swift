//
//  TabBarEnum.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 10/01/25.
//


import SwiftUI

enum TabBarEnum : Hashable{
    case home, catalogue, scan, stores, more
    var iconName  : String {
        switch self
        {
        case .home:
            return "house"
        case .catalogue:
            return "percent"
        case .scan:
            return "qrcode.viewfinder"
        case .stores:
            return "mappin"
        case .more:
            return "ellipsis.circle"
        }
    }
    var title  : String {
        switch self
        {
        case .home:
            return "Home"
        case .catalogue:
            return "Catalogue"
        case .scan:
            return ""
        case .stores:
            return "Store"
        case .more:
            return "More"
        }
    }
    var color  : Color {
        switch self
        {
        case .home, .catalogue, .scan, .stores, .more:
            return Color.red

        }
    }
}
