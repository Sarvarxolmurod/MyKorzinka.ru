import SwiftUI

class TabSelectionModel: ObservableObject {
    @Published var selection: TabBarEnum = .home
}

struct TabBarApp: View {
    @StateObject private var tabModel = TabSelectionModel()
    @State private var showView: Bool = false
    @State private var offset: CGFloat = -UIScreen.main.bounds.height * 0.5

    var body: some View {
        ZStack {
            // Main Tab Bar with Pages
            CustomTabBarConainerView(selection: $tabModel.selection) {
                HomePage()
                    .TabBarItem(tab: .home, selection: $tabModel.selection)

                Catalogue()
                    .TabBarItem(tab: .catalogue, selection: $tabModel.selection)

                Color.cyan
                    .TabBarItem(tab: .scan, selection: $tabModel.selection)

                Color.black
                    .TabBarItem(tab: .stores, selection: $tabModel.selection)

                HomePage()
                    .TabBarItem(tab: .more, selection: $tabModel.selection)
            }
            .ignoresSafeArea(edges : .bottom)

            
            if showView {
                VStack {
                    Spacer()
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                        .frame(height: UIScreen.main.bounds.height * 0.5)
                        .offset(y: offset)
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    if value.translation.height > 0 {
                                        offset = value.translation.height
                                    }
                                }
                                .onEnded { value in
                                    if offset > 100 {
                                        withAnimation {
                                            showView = false
                                            offset = -UIScreen.main.bounds.height * 0.5
                                        }
                                    } else {
                                        withAnimation {
                                            offset = 0
                                        }
                                    }
                                }
                        )
                        .transition(.move(edge: .bottom))
                        .animation(.easeInOut, value: showView)
                }
                .ignoresSafeArea(edges: .bottom)
            }
        }
        
        .onReceive(tabModel.$selection) { newSelection in
            if newSelection == .more {
                withAnimation {
                    showView = true
                    offset = 0
                }
            } else {
                withAnimation {
                    showView = false
                    offset = -UIScreen.main.bounds.height * 0.5
                }
            }
        }
    }
}

#Preview {
    TabBarApp()
}
