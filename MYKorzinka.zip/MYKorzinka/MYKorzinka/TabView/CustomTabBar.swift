//
//  CustomTabBar.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 10/01/25.
//

import SwiftUI

struct CustomTabBar: View {
    let tabs : [TabBarEnum]
    @Binding var selection : TabBarEnum
    var body: some View {
        HStack{
            
            ForEach(tabs, id: \.self){tab in
                tabarItem(tab: tab)
                    .onTapGesture {
                        selection  = tab
                    }
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 20)
        .background(
            UnevenRoundedRectangle(
                cornerRadii: (topLeading: 20, bottomLeading: 0, bottomTrailing: 0, topTrailing: 20)
            )
            .fill(Color.white) // Fill with a color
            .shadow(color: .gray.opacity(0.5), radius: 10, x: 0, y: 5) // Apply shadow with radius
            .ignoresSafeArea(edges: .bottom) // Ignore safe area on the bottom
            .offset(y: -15) // Move the shape upwards slightly
        )
                      
                    
    }
}

#Preview {
    @Previewable @State var selection : TabBarEnum = .home
    CustomTabBar(tabs: [.home, .catalogue, .scan, .stores, .more], selection: $selection)
}
extension CustomTabBar  {

    private func switchtotab (tab : TabBarEnum){
        withAnimation(.easeInOut){
            selection = tab
        }
    }
    private func tabarItem(tab: TabBarEnum) -> some View {
        VStack {
            if tab == .scan {
                Ellipse()
                    .fill(Color.red.opacity(0.8)) // Background color
                    .frame(width: 85, height: 70)
                    .rotationEffect(.degrees(-70))// Larger ellipse
                    .overlay(
                        VStack {
                            Image(systemName: tab.iconName)
                                .font(.system(size: 30)) // Icon size
                                .foregroundColor(.white)
                        }
                    )
                    
            } else {
                Image(systemName: tab.iconName)
                    .font(.system(size: 25))
                
                Text(tab.title)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
            }
        }
        .foregroundColor(selection == tab ? tab.color : Color.gray)
        .offset(y: -15)
        .frame(maxWidth: .infinity)
        .padding(.vertical,  -10)
        
    }
}


