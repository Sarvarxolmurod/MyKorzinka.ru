//
//  CustomTabBarConainerView.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 11/01/25.
//

import SwiftUI

struct CustomTabBarConainerView<Content : View> : View {
    @Binding var selection : TabBarEnum
    let content : Content
    init( selection : Binding<TabBarEnum> , @ViewBuilder content: () -> Content  ){
        self._selection = selection
        self.content = content()
    }
    var body: some View {
        VStack(spacing: 0){
            ZStack {
                content
            }.ignoresSafeArea(edges: .bottom)
            CustomTabBar(tabs: [.home, .catalogue, .scan,.stores, .more], selection: $selection)
        }.ignoresSafeArea(edges : .bottom)
    }
}

#Preview {
    @Previewable @State var selection : TabBarEnum = .home
    CustomTabBarConainerView(selection: $selection, content: {
        Color.red
    } )
}
