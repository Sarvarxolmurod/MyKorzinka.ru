//
//  TabBarItemModifier.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 11/01/25.
//


import SwiftUI

struct TabBarItemModifier : ViewModifier {

    
    let tab : TabBarEnum
    @Binding var selection : TabBarEnum
    func body(content : Content)-> some View{
        content
            .opacity(selection == tab ? 1 : 0)
            .tag(tab)
    }
}
extension View{
    func TabBarItem(tab : TabBarEnum, selection : Binding<TabBarEnum> )-> some View {
        self.modifier(TabBarItemModifier(tab: tab, selection: selection))
    }
}
