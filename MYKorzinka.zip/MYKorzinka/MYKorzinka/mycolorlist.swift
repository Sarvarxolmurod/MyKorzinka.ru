//
//  mycolorlist.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 10/12/24.
//

import Foundation
import SwiftUI
let reddish = Color("reddish")
