//
//  Textview.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 10/12/24.
//

import SwiftUI

struct Textview: View {
    var body: some View {
       
            
               
        HStack{
           
                VStack(alignment: .leading) {
                   
                    Text("Welcome")
                    .font(.system(size: 60, weight:.bold))
                    .foregroundColor(Color.white)
                        .fontWeight(.bold)
                        .fontDesign(.rounded)
                    Text("to Korzinka")
                    .font(.system(size: 60, weight:.bold))
                    .foregroundColor(Color.white)
                        .fontWeight(.bold)
                        .fontDesign(.rounded)
                   
                    Text("Plus Loyalty")
                    .font(.system(size: 60, weight:.bold))
                    .foregroundColor(Color.white)
                        .fontWeight(.bold)
                        .fontDesign(.rounded)
                    Text("Program")
                    .font(.system(size: 60, weight:.bold))
                    .foregroundColor(Color.white)
                        .fontWeight(.bold)
                        .fontDesign(.rounded)
                    
                        
                    
                    
                   
                }
            
            Spacer()
                
                
               
            
           
        }
       
        
        
        
    
    }
}

#Preview {
    Textview()
}
