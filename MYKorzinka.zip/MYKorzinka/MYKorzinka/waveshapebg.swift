import SwiftUI

struct WaveBackgroundView: View {
    var body: some View {
        WaveShape()
            .fill(Color.red) // Set the background color to red
            .edgesIgnoringSafeArea(.all) // Extend to the top edge of the screen
    }
}

struct WaveShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        // Adjusting starting point lower if needed
        let startY = rect.maxY * 0.3 // Start 80% down the height of the view

        // Start from the bottom left
        path.move(to: CGPoint(x: 0, y: rect.maxY))
        
        // Draw line up to the new start of the wave
        path.addLine(to: CGPoint(x: 0, y: startY))
        
        // Modify the curve to lower the peak of the wave
        let controlPoint1 = CGPoint(x: rect.midX / 2, y: startY - 150) // Lower control point by reducing Y value
        let controlPoint2 = CGPoint(x: rect.midX * 3.5, y: startY + 10) // Adjust this to control the wave shape
        path.addCurve(to: CGPoint(x: rect.maxX, y: startY + 0), // Adjust end point of the curve
                      control1: controlPoint1,
                      control2: controlPoint2)
        
        // Draw line back to the bottom right
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        
        // Close the path
        path.closeSubpath()
        
        return path
    }
}

struct WaveBackgroundView_Previews: PreviewProvider {
    static var previews: some View {
        WaveBackgroundView()
    }
}
