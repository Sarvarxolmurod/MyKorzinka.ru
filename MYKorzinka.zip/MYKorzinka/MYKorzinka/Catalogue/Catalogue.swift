//
//  Catalogue.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 18/12/24.
//

import SwiftUI

struct Catalogue: View {


    var body: some View {
        
       
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: -40){
                    ScrollviewTop()
                    
                    HStack {
                        
                        Text("Catalogue")
                            .font(.system(size: 50, weight: .bold, design: .rounded))
                        
                        Spacer()
                    }.padding(.horizontal, 30)
                }
            
                CollectionView(price: 36990, discountpersentage: 20)
                
            }
            .padding(.vertical, 5)
        
    }
}

#Preview {
    Catalogue()
}

