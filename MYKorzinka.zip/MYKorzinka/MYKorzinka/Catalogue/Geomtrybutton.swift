//
//  GeometryReader.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 24/01/25.
//

import SwiftUI

struct Geomtrybutton: View {
    var body: some View {
        GeometryReader{ geo in
            
            let minY = geo.frame(in: .global).minY
            ScrollView(.horizontal, showsIndicators: false)
            {
                
                HStack{
                    
                    Button {
                        
                    } label: {
                        ForEach(0..<20, id: \.self){
                            buttons in  Button("Order") {
                                
                            }
                            .foregroundColor(Color.white)
                            .padding(.horizontal, 60)
                            .padding()
                            .background(
                                UnevenRoundedRectangle(cornerRadii: (topLeading: 20, bottomLeading: 20, bottomTrailing: 20, topTrailing: 20))
                                    .fill(Color.red)
                                    .frame(width: 150, height: 50)
                                
                                    .padding()
                                
                            )
                        }
                        
                    }
                   

                    
                }
                .padding(.vertical, 20)
                .background(Color.white)
                .ignoresSafeArea(.all)
                
              
            }
            .offset(y : max(50 - minY, 0))
        }.offset(y: -30)
            .zIndex(1)
    }
}

#Preview {
    Geomtrybutton()
}
//@ViewBuilder
//func mygeometry() -> some View {
//    GeometryReader{ geo in
//        let minY = geo.frame(in: .global).minY
//       
//        
//        
//    }.frame(height: 200)
//}
