//
//  CollectionView.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 24/01/25.
//

import SwiftUI

struct CollectionView: View {
    let price : Double

    let discountpersentage : Int?
    var discount : Double? {
        if let  discountpersentage{
            return (Double(100 - discountpersentage) / 100) * price
        }else{ return  nil}
    }
    var body: some View {
        VStack(spacing: 60){
            
            Geomtrybutton()
       
            ScrollView(.vertical, showsIndicators: false){
                VStack {
                    VStack(spacing: 20){
                        Text("By pressing Order button you will be transferred to Korzinka Go app with delivery within Tashkent")
                            .foregroundColor(Color.gray)
                            .fontDesign(.rounded)
                        
                        Text("Everything for your home")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                    }
                    .padding()
                    
                    
                    ForEach(0..<40){ product in
                        
                        VStack {
                            HStack{
                                ZStack{
                                    Image("juice")
                                        .resizable()
                                        .frame(width: 100, height: 150)
                                    
                                    VStack{
                                        Text("\(price, specifier : "%.0f")")
                                            .strikethrough(true)
                                            .foregroundColor(Color.red)
                                            .offset(y: 10)
                                            .fontWeight(.semibold)
                                            .font(.system(size : 15))
                                        
                                        Text("\(discount!, specifier : "%.0f")")
                                            .foregroundColor(Color.red)
                                            .offset(y: 10)
                                            .fontWeight(.bold)
                                        
                                        
                                        
                                        if let discountpersentage{
                                            Text("-\(discountpersentage)%")
                                                .fontWeight(.semibold)
                                                .foregroundColor(Color.white)
                                                .font(.system(size : 15))
                                                .rotationEffect(.degrees(50))
                                            
                                            
                                                .background(
                                                    Ellipse()
                                                        .fill(Color.red)
                                                        .frame(width: 60, height: 40)
                                                    
                                                )
                                                .offset(x : 10, y:  40)
                                                .rotationEffect(.degrees(-50))
                                            
                                        }
                                    }
                                    .rotationEffect(.degrees(50))
                                    .background(
                                        Ellipse()
                                            .fill(Color(UIColor.systemYellow))
                                            .frame(width: 120, height: 80)
                                        
                                    )
                                    .offset(x : -10, y:  60)
                                    .rotationEffect(.degrees(-50))
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                }
                                
                                
                                Spacer()
                                ZStack{
                                    Image("popcorn")
                                        .resizable()
                                        .frame(width: 100, height: 150)
                                    
                                    VStack{
                                        Text("\(price, specifier : "%.0f")")
                                            .strikethrough(true)
                                            .foregroundColor(Color.red)
                                            .offset(y: 10)
                                            .fontWeight(.semibold)
                                            .font(.system(size : 15))
                                        
                                        Text("\(discount!, specifier : "%.0f")")
                                            .foregroundColor(Color.red)
                                            .offset(y: 10)
                                            .fontWeight(.bold)
                                        
                                        
                                        
                                        if let discountpersentage{
                                            Text("-\(discountpersentage)%")
                                                .fontWeight(.semibold)
                                                .foregroundColor(Color.white)
                                                .font(.system(size : 15))
                                                .rotationEffect(.degrees(50))
                                            
                                            
                                                .background(
                                                    Ellipse()
                                                        .fill(Color.red)
                                                        .frame(width: 60, height: 40)
                                                    
                                                )
                                                .offset(x : 10, y:  40)
                                                .rotationEffect(.degrees(-50))
                                            
                                        }
                                    }
                                    .rotationEffect(.degrees(50))
                                    .background(
                                        Ellipse()
                                            .fill(Color(UIColor.systemYellow))
                                            .frame(width: 120, height: 80)
                                        
                                    )
                                    .offset(x : -10, y:  60)
                                    .rotationEffect(.degrees(-50))
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                }
                            }.padding(.horizontal, 70)
                                .padding(.vertical, 30)
                            HStack(spacing: 100) {
                                Text("Juice 0.5L")
                                Text("Popcorn 100 Gr")
                            }
                            .padding(.horizontal, 0)
                            .font(.system(size: 15, weight: .semibold, design: .rounded))                        }
                        
                        HStack(spacing: 120){
                            Button("Order") {
                                
                            }
                            .foregroundColor(Color.black)
                            .padding()
                            .background(
                                UnevenRoundedRectangle(cornerRadii: (topLeading: 20, bottomLeading: 20, bottomTrailing: 20, topTrailing: 20))
                                    .fill(Color(UIColor.systemGray5))
                                    .frame(width: 150, height: 50)
                                
                                    .padding()
                                
                            )
                            
                            
                            Button("Order") {
                                
                            }
                            .foregroundColor(Color.black)
                            .padding()
                            .background(
                                UnevenRoundedRectangle(cornerRadii: (topLeading: 20, bottomLeading: 20, bottomTrailing: 20, topTrailing: 20))
                                    .fill(Color(UIColor.systemGray5))
                                    .frame(width: 150, height: 50)
                                
                                    .padding()
                                
                            )
                        }
                        
                    }
                }
            }
            
         
            
        }
    }
}

#Preview {
    CollectionView(price: 36990, discountpersentage: 20)
}
