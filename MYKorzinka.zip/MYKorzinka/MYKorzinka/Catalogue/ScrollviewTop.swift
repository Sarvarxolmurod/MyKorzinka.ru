//
//  ScrollviewTop.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 24/01/25.
//

import SwiftUI

struct ScrollviewTop: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false){
            VStack {
                
                HStack{
                    ForEach(0..<20, id: \.self ){
                        item in
                        
                        UnevenRoundedRectangle1(
                            cornerRadii: (
                                topLeading: 40,
                                bottomLeading: 40,
                                bottomTrailing: 40,
                                topTrailing: 40
                            ),
                            horizontalOffset: 25 // Skew the top portion to the right
                        )
                        .fill(Color.red)
                        .frame(width: 200, height: 200)
                        .padding(.horizontal, 30)
                        .overlay{
                            VStack{
                                Spacer()
                                VStack(alignment: .leading){
                                    
                                    Text("Even lower prices")
                                        .font(.system(size:20, weight:  .bold, design:  .rounded))
                                        .foregroundColor(Color.white)
                                        .offset(x: 25)
                                    
                                    Text("for daily")
                                        .font(.system(size: 20, weight:  .bold, design:  .rounded))
                                        .foregroundColor(Color.white)
                                        .offset(x: 25)
                                    Text("purchases!")
                                        .font(.system(size: 20, weight:  .bold, design:  .rounded))
                                        .foregroundColor(Color.white)
                                        .offset(x: 25)
                                }
                                Spacer()
                               
                                  
                                HStack{
                                    Spacer()
                                    VStack(alignment: .trailing){
                                        Text("Yanada")
                                            .font(.system(size: 20, weight:  .bold, design:  .rounded))
                                            .foregroundColor(Color.yellow)
                                        Text("arzon")
                                            .font(.system(size: 20, weight:  .bold, design:  .rounded))
                                            .foregroundColor(Color.white)
                                        Text("narx!")
                                            .font(.system(size: 20, weight:  .bold, design:  .rounded))
                                            .foregroundColor(Color.white)
                                    }
                                    Image(systemName: "tag.fill")
                                        .font(.system(size: 40, weight: .bold, design: .rounded))
                                        .foregroundColor(Color.yellow)
                                        .rotationEffect(.degrees(-70))
                                    
                                }
                                .padding(.horizontal, 20)
                                Spacer()
                            }
                        }
                    }
                }.padding(.horizontal, 20)
                Spacer()
                
            }.padding(.vertical, 60)
        }
    }
}

#Preview {
    ScrollviewTop()
}
