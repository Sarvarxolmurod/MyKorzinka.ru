////
////  EnumForCollection.swift
////  MYKorzinka
////
////  Created by To call the owner 94 567 65 27    on 24/01/25.
////
//
//import Foundation
//
//enum Collectedicons: Hashable{
//    case vegtables, juices, meats, clohts
//    var names : String{
//        switch self{
//        case .vegtables : return "
//        }
//    }
//}
