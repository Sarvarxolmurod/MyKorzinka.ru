import SwiftUI

struct UnevenRoundedRectangle1: Shape {
    var cornerRadii: (topLeading: CGFloat, bottomLeading: CGFloat, bottomTrailing: CGFloat, topTrailing: CGFloat)
    var horizontalOffset: CGFloat = 0 // Skew amount
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        // Define the corners using the provided radii
        let tl = cornerRadii.topLeading
        let bl = cornerRadii.bottomLeading
        let br = cornerRadii.bottomTrailing
        let tr = cornerRadii.topTrailing
        
        // Skew the top to the right (horizontal offset)
        let topOffset = horizontalOffset
        
        // Start at the top-left corner
        path.move(to: CGPoint(x: rect.minX + tl + topOffset, y: rect.minY))
        
        // Top edge
        path.addLine(to: CGPoint(x: rect.maxX - tr + topOffset, y: rect.minY))
        path.addArc(center: CGPoint(x: rect.maxX + tr - topOffset, y: rect.minY + tr), radius: tr,
                    startAngle: Angle(degrees: 270), endAngle: Angle(degrees: 360), clockwise: false)
        
        // Trailing edge
        path.addLine(to: CGPoint(x: rect.maxX + topOffset, y: rect.maxY - br))
        path.addArc(center: CGPoint(x: rect.maxX - br + topOffset, y: rect.maxY - br), radius: br,
                    startAngle: Angle(degrees:0), endAngle: Angle(degrees: 90), clockwise: false)
        
        // Bottom edge (no horizontal offset)
        path.addLine(to: CGPoint(x: rect.minX + bl, y: rect.maxY))
        path.addArc(center: CGPoint(x: rect.minX + bl, y: rect.maxY - bl), radius: bl,
                    startAngle: Angle(degrees: 90), endAngle: Angle(degrees: 180), clockwise: false)
        
        // Leading edge
        path.addLine(to: CGPoint(x: rect.minX + topOffset, y: rect.minY + tl))
        path.addArc(center: CGPoint(x: rect.minX + tl + topOffset, y: rect.minY + tl), radius: tl,
                    startAngle: Angle(degrees: 180), endAngle: Angle(degrees: 270), clockwise: false)
        
        path.closeSubpath()
        
        return path
    }
}

struct ContentView3: View {
    var body: some View {
        UnevenRoundedRectangle1(
            cornerRadii: (
                topLeading: 40,
                bottomLeading: 40,
                bottomTrailing: 40,
                topTrailing: 40
            ),
            horizontalOffset: 25 // Skew the top portion to the right
        )
        .fill(Color.red)
        .frame(width: 200, height: 250)
        .overlay(
            VStack {
                Text("Even lower prices\nfor daily purchases!")
                    .font(.headline)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                Spacer()
                HStack {
                    Image(systemName: "tag.fill")
                        .foregroundColor(.yellow)
                    Text("Yanada arzon narx!")
                        .foregroundColor(.white)
                        .font(.subheadline)
                        .bold()
                }
            }
            .padding()
        )
    }
}

#Preview {
    ContentView3()
}
