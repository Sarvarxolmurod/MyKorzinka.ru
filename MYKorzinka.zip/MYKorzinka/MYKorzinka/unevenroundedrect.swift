import SwiftUI

struct UnevenRoundedRectangle: Shape {
    var cornerRadii: (topLeading: CGFloat, bottomLeading: CGFloat, bottomTrailing: CGFloat, topTrailing: CGFloat)

    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        // Define the corners using the provided radii
        let tl = cornerRadii.topLeading    // Top leading corner
        let bl = cornerRadii.bottomLeading // Bottom leading corner
        let br = cornerRadii.bottomTrailing // Bottom trailing corner
        let tr = cornerRadii.topTrailing   // Top trailing corner
        
        // Start at the top leading corner
        path.move(to: CGPoint(x: rect.minX + tl, y: rect.minY))
        
        // Top edge
        path.addLine(to: CGPoint(x: rect.maxX - tr, y: rect.minY))
        path.addArc(center: CGPoint(x: rect.maxX - tr, y: rect.minY + tr), radius: tr,
                    startAngle: Angle(degrees: 270), endAngle: Angle(degrees: 360), clockwise: false)
        
        // Trailing edge
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - br))
        path.addArc(center: CGPoint(x: rect.maxX - br, y: rect.maxY - br), radius: br,
                    startAngle: Angle(degrees: 0), endAngle: Angle(degrees: 90), clockwise: false)
        
        // Bottom edge
        path.addLine(to: CGPoint(x: rect.minX + bl, y: rect.maxY))
        path.addArc(center: CGPoint(x: rect.minX + bl, y: rect.maxY - bl), radius: bl,
                    startAngle: Angle(degrees: 90), endAngle: Angle(degrees: 180), clockwise: false)
        
        // Leading edge
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + tl))
        path.addArc(center: CGPoint(x: rect.minX + tl, y: rect.minY + tl), radius: tl,
                    startAngle: Angle(degrees: 180), endAngle: Angle(degrees: 270), clockwise: false)
        
        path.closeSubpath()
        
        return path
    }
}

struct ContentView: View {
    var body: some View {
        Button(action: {
            print("Button tapped")
        }) {
            Text("Continue")
                .foregroundColor(.white)
                .padding(.horizontal, 50) // Padding for the text inside the button
                .padding(.vertical, 20)   // Padding for the text inside the button
                .frame(width: 300, height: 60) // Size of the button
        }
        .background(
            UnevenRoundedRectangle(cornerRadii: (40,20, 40, 0)) // Radii for each corner
                .fill(Color.red)
        )
        .clipShape(
            UnevenRoundedRectangle(cornerRadii: (40, 10, 0, 20))
        )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
