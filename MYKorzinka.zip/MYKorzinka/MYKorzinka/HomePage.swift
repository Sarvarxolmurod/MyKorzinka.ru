import SwiftUI

struct HomePage: View {

    var body: some View {
        
        NavigationStack {
            ZStack(alignment: .bottom) {
         
                Image("background")
                    .resizable()
                    .ignoresSafeArea()
                WaveShape()
                    .fill(.red)
                    .ignoresSafeArea(.all)
               

                VStack {
                    HomeView()
                    Spacer()
                }.padding(.horizontal, 40)
                
              
               
            }
            .ignoresSafeArea(edges: .bottom)
            
        }.navigationBarBackButtonHidden()
        }
}

#Preview {
    HomePage()
}
