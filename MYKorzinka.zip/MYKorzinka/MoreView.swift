//
//  MoreView.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 18/12/24.
//

import SwiftUI

struct MoreView: View {
    @StateObject private var tabModel = TabSelectionModel()
    @State private var showView: Bool = false
    @State private var offset: CGFloat = -UIScreen.main.bounds.height * 0.5
    var body: some View {
        ZStack{
            if showView {
                VStack {
                    Spacer()
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                        .frame(height: UIScreen.main.bounds.height * 0.5)
                        .offset(y: offset)
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    if value.translation.height > 0 {
                                        offset = value.translation.height
                                    }
                                }
                                .onEnded { value in
                                    if offset > 100 {
                                        withAnimation {
                                            showView = false
                                            offset = -UIScreen.main.bounds.height * 0.5
                                        }
                                    } else {
                                        withAnimation {
                                            offset = 0
                                        }
                                    }
                                }
                        )
                        .transition(.move(edge: .bottom))
                        .animation(.easeInOut, value: showView)
                }
                .ignoresSafeArea(edges: .bottom)
            }
        }
        
        .onReceive(tabModel.$selection) { newSelection in
            if newSelection == .more {
                withAnimation {
                    showView = true
                    offset = 0
                }
            } else {
                withAnimation {
                    showView = false
                    offset = -UIScreen.main.bounds.height * 0.5
                }
            }
        }
   
    }
}

#Preview {
    MoreView()
}
