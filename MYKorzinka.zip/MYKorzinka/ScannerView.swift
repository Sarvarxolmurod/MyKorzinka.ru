//
//  ScannerView.swift
//  MYKorzinka
//
//  Created by To call the owner 94 567 65 27    on 19/12/24.
//

import SwiftUI

struct ScannerView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ScannerView()
}
